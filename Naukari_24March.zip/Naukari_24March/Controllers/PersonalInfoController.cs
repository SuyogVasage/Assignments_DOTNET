﻿using Microsoft.AspNetCore.Mvc;
using Naukari_24March.Models;
using Naukari_24March.Services;
using System;
using Microsoft.AspNetCore.Http;
using Naukari_24March.CustomSession;
using System.Linq;
using System.Collections.Generic;

namespace Naukari_24March.Controllers
{
    public class PersonalInfoController : Controller
    {
        private readonly IService<PersonalInfo, int> personalInfoService;
        private readonly IService<EducationInfo, int> educationService;
        private readonly IService<ProfessionalInfo, int> professionalService;     


        public PersonalInfoController(IService<PersonalInfo, int> personalInfoService, IService<EducationInfo, int> educationService, IService<ProfessionalInfo, int> professionalService)
        {
            this.personalInfoService = personalInfoService;
            this.educationService = educationService;
            this.professionalService = professionalService;
        }
        public IActionResult Index()
        {
            var pInfo = new PerEdu();
            pInfo.eduInfos= educationService.GetAsync().Result.ToList();
            pInfo.personalInfos = personalInfoService.GetAsync().Result.ToList();
            var Resultant = from p in pInfo.personalInfos
                            join e in pInfo.eduInfos on
                            p.CandidateId equals e.CandidateId
                            select new
                            {
                                CandidateID = p.CandidateId,
                                FullName = p.FullName,
                                MobileNo = p.MobileNo,
                                Email = p.Email,
                                Highest_Qualification = e.DegreeName,
                                ImgPath = p.ImgPath
                            };
            pInfo.ShowInfos = new List<ShowInfo>();
            //List<ShowInfo> infoList = new List<ShowInfo>();
            foreach (var d in Resultant)
            {
                pInfo.ShowInfos.Add(new ShowInfo() { CandidateId = d.CandidateID, FullName = d.FullName, MobileNo = d.MobileNo, Email = d.Email, Highest_Qualification = d.Highest_Qualification, ImgPath = d.ImgPath});
            }
            return View(pInfo);
        }

        public IActionResult Create()
        {
            var user = new PersonalInfo();
            return View(user);
        }

        [HttpPost]
        public IActionResult Create(PersonalInfo personalInfo)
        {
            //var result = personalInfoService.CreateAsync(personalInfo).Result;
            HttpContext.Session.SetObject<PersonalInfo>("Personal", personalInfo);
            
            return RedirectToAction("Create", "EducationalInfo");
        }

        public IActionResult Details( int id)
        {
            //var pInfo = new PerEdu();
            //pInfo.eduInfos = educationService.GetAsync().Result.ToList();
            //pInfo.personalInfos = personalInfoService.GetAsync().Result.ToList();
            //pInfo.professionalInfos = professionalService.GetAsync().Result.ToList();

            var education = educationService.GetAsync().Result.ToList().Where(x=>x.CandidateId == id).FirstOrDefault();
            var personal = personalInfoService.GetAsync(id).Result;
            var professional = professionalService.GetAsync().Result.ToList().Where(x => x.CandidateId == id).FirstOrDefault();

            ShowAllInfo show = new ShowAllInfo()
            {
                CandidateID = personal.CandidateId,
                FullName = personal.FullName,
                MobileNo = personal.MobileNo,
                Address = personal.MobileNo,
                SscpassYear = education.SscpassYear,
                Sscpercentage = education.Sscpercentage,
                HscpassYear = education.HscpassYear,
                Hscpercentage = education.Hscpercentage,
                DiplomaPassYear = education.DiplomaPassYear,
                DiplomaPercentage = education.DiplomaPercentage,
                DegreeName = education.DegreeName,
                DegreePassYear = education.DegreePassYear,
                DegreePercentage = education.DegreePercentage,
                MastersName = education .MastersName,
                MastersPassYear = education.MastersPassYear,
                MastersPercentage = education.MastersPercentage,
                ExpInYears = professional.ExpInYears,
                Companies = professional.Companies,
                Projects = professional.Projects,
                ImgPath = personal.ImgPath,
                ResumePath = personal.ResumePath
            };
            //var Resultant = from p in pper
            //                join e in per
            //                on p.CandidateId equals e.CandidateId
            //                join pro in pros
            //                on p.CandidateId equals pro.CandidateId
            //                select new
            //                {
            //                    CandidateID = p.CandidateId,
            //                    FullName = p.FullName,
            //                    MobileNo = p.MobileNo,
            //                    Email = p.Email,
            //                    Address = p.Address,
            //                    SSCPassYear = e.SscpassYear,
            //                    SSCPercentage = e.Sscpercentage,
            //                    HSCPassYear = e.HscpassYear,
            //                    HSCPercentage = e.Hscpercentage,
            //                    DiplomaPasYear = e.DiplomaPassYear,
            //                    DiplomaPercentage = e.DiplomaPercentage,
            //                    DegreePassYear = e.DegreePassYear,
            //                    DegreePercentage = e.DegreePercentage,
            //                    DegreeName = e.DegreeName,
            //                    MasterPassYear = e.MastersPassYear,
            //                    MasterPercentage = e.MastersPercentage,
            //                    MasterName = e.MastersName,
            //                    ExpInYears = pro.ExpInYears,
            //                    Companies = pro.Companies,
            //                    Projects = pro.Projects,
            //                    ImgPath = p.ImgPath,
            //                    Resumepath = p.ResumePath
            //                };
            //pInfo.ShowAllInfos = new List<ShowAllInfo>();
            //foreach (var d in Resultant)
            //{
            //    pInfo.ShowAllInfos.Add(new ShowAllInfo()
            //    {
            //        CandidateID = d.CandidateID,
            //        FullName = d.FullName,
            //        MobileNo = d.MobileNo,
            //        Email = d.Email,
            //        Address = d.Address,
            //        SscpassYear = d.SSCPassYear,
            //        Sscpercentage = d.SSCPercentage,
            //        HscpassYear = d.HSCPassYear,
            //        Hscpercentage = d.HSCPercentage,
            //        DiplomaPassYear = d.DiplomaPasYear,
            //        DiplomaPercentage = d.DiplomaPercentage,
            //        DegreePassYear = d.DegreePassYear,
            //        DegreePercentage = d.DegreePercentage,
            //        DegreeName = d.DegreeName,
            //        MastersPassYear = d.MasterPassYear,
            //        MastersPercentage = d.MasterPercentage,
            //        MastersName = d.MasterName,
            //        ExpInYears = d.ExpInYears,
            //        Companies = d.Companies,
            //        Projects = d.Projects,
            //        ImgPath = d.ImgPath,
            //        ResumePath = d.Resumepath
            //    });
            //}

            return View(show);
        }
    }
}
