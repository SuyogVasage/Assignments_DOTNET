﻿using System.ComponentModel.DataAnnotations;

namespace Naukari_24March.Models
{
    public class ShowInfo
    {
        [Key]
        public int CandidateId { get; set; }
        public string FullName { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string Highest_Qualification { get; set; }
        public string ImgPath { get; set; }
    }
}

//@model Naukari_24March.Models.ShowAllInfo

//@{
//    ViewData["Title"] = "Details";
//}

//< h1 > Details </ h1 >
//< hr />
//< div >
//    < h4 > PerEdu </ h4 >
//    < hr />
//    < dl class= "row" >
 
//         < dt class = "col-sm-2" >
//              @Html.DisplayNameFor(model => model.CandidateID)
//          </ dt >
  
//          < dd class = "col-sm-10" >
//               @Html.DisplayFor(model => model.CandidateID)
//           </ dd >
   
//           < dt class = "col-sm-2" >
//                @Html.DisplayNameFor(model => model.FullName)
//            </ dt >
    
//            < dd class = "col-sm-10" >
//                 @Html.DisplayFor(model => model.FullName)
//             </ dd >
     
//             < dt class = "col-sm-2" >
//                  @Html.DisplayNameFor(model => model.MobileNo)
//              </ dt >
      
//              < dd class = "col-sm-10" >
//                   @Html.DisplayFor(model => model.MobileNo)
//               </ dd >
       
//               < dt class = "col-sm-2" >
//                    @Html.DisplayNameFor(model => model.Email)
//                </ dt >
        
//                < dd class = "col-sm-10" >
//                     @Html.DisplayFor(model => model.Email)
//                 </ dd >
         
//                 < dt class = "col-sm-2" >
//                      @Html.DisplayNameFor(model => model.Address)
//                  </ dt >
          
//                  < dd class = "col-sm-10" >
//                       @Html.DisplayFor(model => model.Address)
//                   </ dd >
           
//                   < dt class = "col-sm-2" >
//                        @Html.DisplayNameFor(model => model.SscpassYear)
//                    </ dt >
            
//                    < dd class = "col-sm-10" >
//                         @Html.DisplayFor(model => model.SscpassYear)
//                     </ dd >
             
//                     < dt class = "col-sm-2" >
//                          @Html.DisplayNameFor(model => model.Sscpercentage)
//                      </ dt >
              
//                      < dd class = "col-sm-10" >
//                           @Html.DisplayFor(model => model.Sscpercentage)
//                       </ dd >
               
//                       < dt class = "col-sm-2" >
//                            @Html.DisplayNameFor(model => model.HscpassYear)
//                        </ dt >
                
//                        < dd class = "col-sm-10" >
//                             @Html.DisplayFor(model => model.HscpassYear)
//                         </ dd >
                 
//                         < dt class = "col-sm-2" >
//                              @Html.DisplayNameFor(model => model.Hscpercentage)
//                          </ dt >
                  
//                          < dd class = "col-sm-10" >
//                               @Html.DisplayFor(model => model.Hscpercentage)
//                           </ dd >
                   
//                           < dt class = "col-sm-2" >
//                                @Html.DisplayNameFor(model => model.DiplomaPassYear)
//                            </ dt >
                    
//                            < dd class = "col-sm-10" >
//                                 @Html.DisplayFor(model => model.DiplomaPassYear)
//                             </ dd >
                     
//                             < dt class = "col-sm-2" >
//                                  @Html.DisplayNameFor(model => model.DiplomaPercentage)
//                              </ dt >
                      
//                              < dd class = "col-sm-10" >
//                                   @Html.DisplayFor(model => model.DiplomaPercentage)
//                               </ dd >
                       
//                               < dt class = "col-sm-2" >
//                                    @Html.DisplayNameFor(model => model.DegreeName)
//                                </ dt >
                        
//                                < dd class = "col-sm-10" >
//                                     @Html.DisplayFor(model => model.DegreeName)
//                                 </ dd >
                         
//                                 < dt class = "col-sm-2" >
//                                      @Html.DisplayNameFor(model => model.DegreePassYear)
//                                  </ dt >
                          
//                                  < dd class = "col-sm-10" >
//                                       @Html.DisplayFor(model => model.DegreePassYear)
//                                   </ dd >
                           
//                                   < dt class = "col-sm-2" >
//                                        @Html.DisplayNameFor(model => model.DegreePercentage)
//                                    </ dt >
                            
//                                    < dd class = "col-sm-10" >
//                                         @Html.DisplayFor(model => model.DegreePercentage)
//                                     </ dd >
                             
//                                     < dt class = "col-sm-2" >
//                                          @Html.DisplayNameFor(model => model.MastersName)
//                                      </ dt >
                              
//                                      < dd class = "col-sm-10" >
//                                           @Html.DisplayFor(model => model.MastersName)
//                                       </ dd >
                               
//                                       < dt class = "col-sm-2" >
//                                            @Html.DisplayNameFor(model => model.MastersPassYear)
//                                        </ dt >
                                
//                                        < dd class = "col-sm-10" >
//                                             @Html.DisplayFor(model => model.MastersPassYear)
//                                         </ dd >
                                 
//                                         < dt class = "col-sm-2" >
//                                              @Html.DisplayNameFor(model => model.MastersPercentage)
//                                          </ dt >
                                  
//                                          < dd class = "col-sm-10" >
//                                               @Html.DisplayFor(model => model.MastersPercentage)
//                                           </ dd >
                                   
//                                           < dt class = "col-sm-2" >
//                                                @Html.DisplayNameFor(model => model.ImgPath)
//                                            </ dt >
                                    
//                                            < dd class = "col-sm-10" >
//                                                 @Html.DisplayFor(model => model.ImgPath)
//                                             </ dd >
                                     
//                                             < dt class = "col-sm-2" >
//                                                  @Html.DisplayNameFor(model => model.ResumePath)
//                                              </ dt >
                                      
//                                              < dd class = "col-sm-10" >
//                                                   @Html.DisplayFor(model => model.ResumePath)
//                                               </ dd >
                                       
//                                           </ dl >
//                                       </ div >
