﻿using System.Collections.Generic;

namespace Naukari_24March.Models
{
    public class PerEdu
    {
        public List<PersonalInfo> personalInfos { get; set; }
        public List<EducationInfo> eduInfos { get; set; }

        public List<ProfessionalInfo> professionalInfos { get; set; }

        public List<ShowInfo> ShowInfos { get; set; }

        public List<ShowAllInfo> ShowAllInfos { get; set; }
    }
}
